/**
 * Smart Report MCP Plugin for OpenClaw
 */
import axios from 'axios';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';

const PLUGIN_ID = 'smart-report-plugin';
const API_BASE = 'https://smartreport.siapdigital.my.id/api/mcp';

function saveConfig(token: string) {
    const configPath = path.join(os.homedir(), '.openclaw', 'openclaw.json');
    if (fs.existsSync(configPath)) {
        const raw = fs.readFileSync(configPath, 'utf-8');
        const config = JSON.parse(raw);
        if (!config.plugins) config.plugins = {};
        if (!config.plugins.entries) config.plugins.entries = {};
        if (!config.plugins.entries[PLUGIN_ID]) config.plugins.entries[PLUGIN_ID] = {};
        if (!config.plugins.entries[PLUGIN_ID].config) config.plugins.entries[PLUGIN_ID].config = {};
        
        config.plugins.entries[PLUGIN_ID].config.apiToken = token;
        config.plugins.entries[PLUGIN_ID].enabled = true;
        
        fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
    }
}

async function callMcp(api: any, method: string, params: any = {}) {
    const config = (api.config as any).plugins?.entries?.[PLUGIN_ID]?.config;
    const token = config?.apiToken;
    
    if (!token) {
        throw new Error('API Token not found. Please run "openclaw smart-auth <token>" first.');
    }

    const response = await axios.post(API_BASE, {
        jsonrpc: '2.0',
        method: method,
        params: params,
        id: Date.now()
    }, {
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    });

    if (response.data.error) {
        throw new Error(response.data.error.message);
    }

    return response.data.result;
}

/**
 * MCP Activation Hook
 */
export function register(api: any) {
    // 1. CLI Commands
    api.registerCli(({ program }: any) => {
        program
            .command('smart-auth <token>')
            .description('Set API Token for Smart Report integration')
            .action((token: string) => {
                try {
                    saveConfig(token);
                    console.log('✅ Smart Report API Token saved successfully.');
                    process.exit(0);
                } catch (err: any) {
                    console.error('❌ Failed to save config:', err.message);
                    process.exit(1);
                }
            });
    }, { commands: ['smart-auth'] });

    // 2. Resources
    api.registerResource({
        uri: 'smartreport://reports',
        name: 'Recent Reports',
        description: 'Stream of latest submitted reports',
        mimeType: 'application/json',
        read: async () => {
            const data = await callMcp(api, 'reports/list', { per_page: 10 });
            return { content: JSON.stringify(data, null, 2) };
        }
    });

    api.registerResource({
        uri: 'smartreport://employees',
        name: 'Employee List',
        description: 'Complete list of active employees with division names',
        mimeType: 'application/json',
        read: async () => {
            const data = await callMcp(api, 'employees/list', {});
            return { content: JSON.stringify(data, null, 2) };
        }
    });

    api.registerResource({
        uri: 'smartreport://divisions',
        name: 'Division List',
        description: 'List of all divisions in the company',
        mimeType: 'application/json',
        read: async () => {
            const data = await callMcp(api, 'divisions/list', {});
            return { content: JSON.stringify(data, null, 2) };
        }
    });

    api.registerResource({
        uri: 'smartreport://guides',
        name: 'Guides List',
        description: 'List of all available dynamic guides',
        mimeType: 'application/json',
        read: async () => {
            const data = await callMcp(api, 'guides/list', {});
            return { content: JSON.stringify(data, null, 2) };
        }
    });

    api.registerResource({
        uri: 'smartreport://debt-aging',
        name: 'Debt Aging Analysis',
        description: 'Analysis of pending tasks and overdue reports',
        mimeType: 'application/json',
        read: async () => {
            const data = await callMcp(api, 'attendance/list_absent', { include_reason: true });
            return { content: JSON.stringify(data, null, 2) };
        }
    });

    api.registerResource({
        uri: 'smartreport://dashboard',
        name: 'Daily Dashboard',
        description: 'Real-time KPI dashboard (stats, highlights, alerts)',
        mimeType: 'application/json',
        read: async (params: any) => {
            const data = await callMcp(api, 'smartreport/dashboard', params || {});
            return { content: JSON.stringify(data, null, 2) };
        }
    });

    // 3. Agent Tools
    api.registerTool({
        name: 'get_daily_dashboard',
        description: 'Retrieve real-time KPI dashboard (stats, highlights, alerts).',
        execute: async (args: any) => {
            try {
                const data = await callMcp(api, 'smartreport/dashboard', args);
                return { text: JSON.stringify(data, null, 2) };
            } catch (err: any) {
                return { error: err.message };
            }
        }
    });

    api.registerTool({
        name: 'get_guides_list',
        description: 'Retrieve list of all available dynamic guides.',
        execute: async () => {
            try {
                const data = await callMcp(api, 'guides/list', {});
                return { text: JSON.stringify(data, null, 2) };
            } catch (err: any) {
                return { error: err.message };
            }
        }
    });

    api.registerTool({
        name: 'get_guide_content',
        description: 'Retrieve full content of a specific guide by ID.',
        execute: async (args: any) => {
            try {
                const data = await callMcp(api, 'guides/get', args);
                return { text: JSON.stringify(data, null, 2) };
            } catch (err: any) {
                return { error: err.message };
            }
        }
    });

    api.registerTool({
        name: 'get_list_reports',
        description: 'Retrieve reports with filters (date, employee, division).',
        execute: async (args: any) => {
            try {
                const data = await callMcp(api, 'reports/list', args);
                return { text: JSON.stringify(data, null, 2) };
            } catch (err: any) {
                return { error: err.message };
            }
        }
    });

    api.registerTool({
        name: 'get_debt_analysis',
        description: 'Analyze pending tasks and employee performance debt.',
        execute: async (args: any) => {
            try {
                const data = await callMcp(api, 'analyze_performance', args);
                return { text: JSON.stringify(data, null, 2) };
            } catch (err: any) {
                return { error: err.message };
            }
        }
    });
}

// We remove default export and stick to NAMED exports only
// to see if it helps the loader distinguish the module structure.
export const activate = register;
